
  # Social Media App Bliq

  This is a code bundle for Social Media App Bliq. The original project is available at https://www.figma.com/design/SNU3we88MsF5f4meq0RnG3/Social-Media-App-Bliq.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  