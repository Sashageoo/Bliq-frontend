// ФАЙЛ БОЛЬШЕ НЕ НУЖЕН - ТОЛЬКО ТЕМНАЯ ТЕМА
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}